package com.intelli.product.service;

import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.intelli.product.dao.ProductDataStore;
import com.intelli.product.model.ProductCost;
import com.intelli.product.model.ProductDetails;

@RunWith(MockitoJUnitRunner.class)
public class PriceCalculateServiceTest {

	@InjectMocks
	private PriceCalculateService priceCalculateService;
	
	@Mock
	private ProductDataStore dataStore;
	
	private ProductDetails productDetails;
	
	private ProductCost productCost;
	
	@Before
	public void setUp() {
	
		
		productDetails = new ProductDetails();
		productDetails.setName("Product Name");
		productDetails.setDesc("Details related of the PRoduct");
		productDetails.setPrice(115.5);
		
		
		productCost = new ProductCost();
		productCost.setName("Product Name");
		productCost.setTax(101.1);
	}
	
	
	@Test
	public void calculateProductTaxForProductA() {
		productDetails.setProductType("productA");
		productCost.setProductType("productA");
		ProductCost productCost=priceCalculateService.calculateProductTax(productDetails);
		Assert.assertEquals(productDetails.getProductType(), productCost.getProductType());
		Assert.assertNotNull(productCost);
	}
	
	@Test
	public void calculateProductTaxForProductB() {
		
		productDetails.setProductType("productB");
		productCost.setProductType("productB");
		ProductCost productCost=priceCalculateService.calculateProductTax(productDetails);
		Assert.assertEquals(productDetails.getProductType(), productCost.getProductType());
		Assert.assertNotNull(productCost);
	}
	@Test
	public void calculateProductTaxForProductC() {
		
		productDetails.setProductType("productC");
		productCost.setProductType("productC");
		ProductCost productCost=priceCalculateService.calculateProductTax(productDetails);
		Assert.assertEquals(productDetails.getProductType(), productCost.getProductType());
		Assert.assertNotNull(productCost);
	}
	
	@Test
	public void calculateProductTaxById() {	
		productDetails.setProductType("productA");
		productCost.setProductType("productA");
		when(dataStore.productFillIntoMap(10001)).thenReturn(productCost);
		ProductCost productCost=priceCalculateService.calculateProductTaxById(10001);
		Assert.assertEquals(productDetails.getProductType(), productCost.getProductType());
		Assert.assertNotNull(productCost);
	}
	

}
