package com.intelli.product.dao;

import static org.junit.Assert.assertNotNull;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.intelli.product.exception.ProductNotFoundException;
import com.intelli.product.model.ProductCost;
import com.intelli.product.model.ProductDetails;

@RunWith(MockitoJUnitRunner.class)
public class ProductDataStoreTest {

	@InjectMocks
	private ProductDataStore dataStore;

	public Map<Integer, ProductCost> map;

	private ProductDetails productDetails;

	@Before
	public void setUp() {

		ProductCost cost = new ProductCost();
		cost.setProductId(10001);
		cost.setDesc(" This is good for health ");
		cost.setLevy(10);
		cost.setPrice(600.00);
		cost.setName("Product A");
		cost.setProductType("ProductA");
		cost.setTax(60.00);
		map = new ConcurrentHashMap<Integer, ProductCost>();
		map.put(10001, cost);
		productDetails = new ProductDetails();
		productDetails.setName("Product Name");
		productDetails.setDesc("Details related of the PRoduct");
		productDetails.setPrice(600.00);
		productDetails.setProductType("ProductA");
		productDetails.setTax(60.00);
		productDetails.setLevy(10);
	}

	@Test
	public void productFillIntoMapTest() {
		ProductCost cost = dataStore.productFillIntoMap(10001);
		Assert.assertEquals(productDetails.getProductType(), cost.getProductType());
		Assert.assertNotNull(cost);
	}
	
	@Test(expected = ProductNotFoundException.class)
	public void productFillIntoMapTestIdNotAvailable() {
		productDetails.setPrice(6000);
		ProductCost cost = dataStore.productFillIntoMap(10008);
		Assert.assertEquals(productDetails.getPrice(), cost.getPrice());
		assertNotNull(cost);
	}

}
