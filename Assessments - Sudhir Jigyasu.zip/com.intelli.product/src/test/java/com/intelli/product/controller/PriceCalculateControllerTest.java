package com.intelli.product.controller;

import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.intelli.product.model.ProductCost;
import com.intelli.product.model.ProductDetails;
import com.intelli.product.service.PriceCalculateService;

@RunWith(MockitoJUnitRunner.class)
public class PriceCalculateControllerTest {

	@InjectMocks
	private PriceCalculateController priceController;

	@Mock
	private PriceCalculateService priceCalculateServiceTest;

	private ProductDetails productDetails;

	private ProductCost productCost;

	@Before
	public void setUp() {
	
		productDetails = new ProductDetails();
		productDetails.setName("Product Name");
		productDetails.setDesc("Details related of the PRoduct");
		productDetails.setPrice(115.5);
		productDetails.setProductType("productA");
		productDetails.setTax(101.1);
	}

	@Test
	public void testBillGeneration() {
		productCost = new ProductCost();
		productCost.setName("Product Name");
		productCost.setProductType("productA");
		productCost.setTax(101.1);
		productCost.setPrice(115.5);
		when(priceCalculateServiceTest.calculateProductTax(productDetails)).thenReturn(productCost);
		ProductCost cost = priceController.billGeneration(productDetails);
		Assert.assertEquals(productDetails.getProductType(), cost.getProductType());
		Assert.assertEquals(productDetails.getTax(), cost.getTax());
		Assert.assertNotNull(cost);
	}

	
	@Test
	public void testBillGenerationByID() {
		productCost = new ProductCost();
		productCost.setName("Product Name");
		productCost.setProductType("productA");
		productCost.setTax(101.1);
		productCost.setPrice(115.5);
		when(priceCalculateServiceTest.calculateProductTaxById(10001)).thenReturn(productCost);
		ProductCost cost = priceController.billGenerationById(10001);
		Assert.assertEquals(productDetails.getProductType(), cost.getProductType());
		Assert.assertEquals(productDetails.getTax(), cost.getTax());
		Assert.assertNotNull(cost);
	}
	

}
