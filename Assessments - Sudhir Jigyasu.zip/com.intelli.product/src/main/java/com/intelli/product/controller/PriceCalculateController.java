package com.intelli.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.intelli.product.model.ProductCost;
import com.intelli.product.model.ProductDetails;
import com.intelli.product.service.PriceCalculateService;

@RequestMapping("/product")
@RestController
public class PriceCalculateController {

	@Autowired
	private PriceCalculateService priceCalculateService;

	@PostMapping(value = "/bill", produces = MediaType.APPLICATION_JSON_VALUE)
	public ProductCost billGeneration(@RequestBody ProductDetails productDetails) {
		ProductCost cost = priceCalculateService.calculateProductTax(productDetails);
		return cost;
	}

	@RequestMapping(value = "/bill/{productId}")
	public ProductCost billGenerationById(@PathVariable("productId") int productId) {
		ProductCost cost = priceCalculateService.calculateProductTaxById(productId);
		return cost;
	}
	
}
