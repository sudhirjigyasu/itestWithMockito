package com.intelli.product.dao;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Repository;

import com.intelli.product.exception.ProductNotFoundException;
import com.intelli.product.model.ProductCost;

@Repository
public class ProductDataStore {

	public Map<Integer, ProductCost> map;

	public ProductDataStore() {

		//Load the data in Stat-up time 
		
		ProductCost cost = new ProductCost();
		double tax, totalprice;
		map = new ConcurrentHashMap<Integer, ProductCost>();

		tax = 415.50 * 0.1;
		totalprice = 415.50 + tax;
		cost.setTax(tax);
		cost.setPrice(415.50);
		cost.setTotal_price(totalprice);
		cost.setDesc("Product Belongs to Category A");
		cost.setName("Product A");
		cost.setProductType("ProductA");
		cost.setLevy(10);
		cost.setProductId(10001);
		map.put(cost.getProductId(), cost);

		ProductCost cost1 = new ProductCost();
		
		tax = 515.50 * 0.2;
		totalprice = 515.50 + tax;
		cost1.setTax(tax);
		cost1.setPrice(515.50);
		cost1.setTotal_price(totalprice);
		cost1.setDesc("Product Belongs to Category B");
		cost1.setName("Product B");
		cost1.setProductType("ProductB");
		cost1.setLevy(20);
		cost1.setProductId(10002);
		map.put(cost1.getProductId(), cost1);

		ProductCost cost2 = new ProductCost();
		tax = 00.00;
		totalprice = 600.00 + tax;
		cost2.setTax(tax);
		cost2.setPrice(600);
		cost2.setTotal_price(totalprice);
		cost2.setDesc("Product Belongs to Category C");
		cost2.setName("Product C");
		cost2.setProductType("ProductC");
		cost2.setLevy(0);
		cost2.setProductId(10003);
		map.put(cost2.getProductId(), cost2);
	}

	public ProductCost productFillIntoMap(int id) {
		ProductCost cost = new ProductCost();
		if (map.containsKey(id)) {
			cost = map.get(id);
		}else {
			throw new ProductNotFoundException("Product Details Not found in dataBase");
		}
		return cost;
	}

}
