package com.intelli.product.constant;

public class ProductConstant {

	public static String CATEGORY_A = "ProductA";
	public static String CATEGORY_B = "ProductB";
	public static String CATEGORY_C = "ProductC";
}
