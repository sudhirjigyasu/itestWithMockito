package com.intelli.product.service;

import java.io.FileOutputStream;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.intelli.product.constant.ProductConstant;
import com.intelli.product.dao.ProductDataStore;
import com.intelli.product.model.ProductCost;
import com.intelli.product.model.ProductDetails;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class PriceCalculateService {

	@Autowired
	private ProductDataStore productDataStore;

	public ProductCost calculateProductTax(ProductDetails productDetails) {

		ProductCost cost = new ProductCost();
		Random random = new Random();
		double tax, totalprice;
		if (productDetails.getProductType().equalsIgnoreCase(ProductConstant.CATEGORY_A)) {

			tax = productDetails.getPrice() * 0.1;
			totalprice = productDetails.getPrice() + tax;
			cost.setTax(tax);
			cost.setPrice(productDetails.getPrice());
			cost.setTotal_price(totalprice);
			cost.setDesc(productDetails.getDesc());
			cost.setName(productDetails.getName());
			cost.setProductType(productDetails.getProductType());
			cost.setLevy(10);
			cost.setPrice(productDetails.getPrice());
			cost.setProductId(productDetails.getProductId());

		} else if (productDetails.getProductType().equalsIgnoreCase(ProductConstant.CATEGORY_B)) {

			tax = productDetails.getPrice() * 0.2;
			totalprice = productDetails.getPrice() + tax;
			cost.setTax(tax);
			cost.setPrice(productDetails.getPrice());
			cost.setTotal_price(totalprice);
			cost.setDesc(productDetails.getDesc());
			cost.setName(productDetails.getName());
			cost.setProductType(productDetails.getProductType());
			cost.setLevy(20);
			cost.setProductId(productDetails.getProductId());

		} else {
			cost.setTax(0.0);
			cost.setPrice(productDetails.getPrice());
			cost.setTotal_price(productDetails.getPrice());
			cost.setDesc(productDetails.getDesc());
			cost.setName(productDetails.getName());
			cost.setProductType(productDetails.getProductType());
			cost.setLevy(0);
			cost.setProductId(random.nextInt(1000));
		}

		pdfReportGenerate(cost);
		return cost;
	}

	public ProductCost calculateProductTaxById(int productId) {
		ProductCost cost = productDataStore.productFillIntoMap(productId);
		pdfReportGenerate(cost);
		return cost;
	}

	private void pdfReportGenerate(ProductCost cost) {
		Document document = new Document();
		try {
			PdfWriter writer = PdfWriter.getInstance(document,
					new FileOutputStream("C:\\Users\\intelliswift.test\\Downloads\\SetAttributeExample.pdf"));
			document.open();
			document.add(new Paragraph("Product Details : "));

			PdfPTable table = new PdfPTable(2);
			table.addCell("Product Id : ");
			table.addCell(String.valueOf(cost.getProductId()));

			table.addCell("Name : ");
			table.addCell(cost.getName());

			table.addCell("Product Type : ");
			table.addCell(cost.getProductType());

			table.addCell("Product Price : ");
			table.addCell(String.valueOf(cost.getPrice()));

			table.addCell("Tax : ");
			table.addCell(String.valueOf(cost.getTax()));

			table.addCell("Levy : ");
			table.addCell(String.valueOf(cost.getLevy()));

			table.addCell("Total Price : ");
			table.addCell(String.valueOf(cost.getTotal_price()));

			document.add(table);

			document.close();
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
