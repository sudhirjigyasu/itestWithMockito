package com.intelli.product.model;

public class ProductCost {

	private Double total_price;
	private Double tax;
	private String name;
	private String desc;
	private String productType;
	private double levy;
	private int productId;
	private double price;
	

	public Double getTotal_price() {
		return total_price;
	}

	public void setTotal_price(Double total_price) {
		this.total_price = total_price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public double getLevy() {
		return levy;
	}

	public void setLevy(double levy) {
		this.levy = levy;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getTax() {
		return tax;
	}

	public void setTax(Double tax) {
		this.tax = tax;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	@Override
	public String toString() {
		return "ProductCost [total_price=" + total_price + ", tax=" + tax + ", name=" + name + ", desc=" + desc
				+ ", productType=" + productType + ", levy=" + levy + ", productId=" + productId + ", price=" + price
				+ "]";
	}




}
